# Nemroot Saraf gelir gider takip sistemi

PHP Version 8x versiyonlarında çalışır

.env de ki bilgileri kendinize uygun değiştiriniz...