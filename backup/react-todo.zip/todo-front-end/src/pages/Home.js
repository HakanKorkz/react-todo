export function Home({props}) {
    return (
        <div className="min-w-full min-h-screen">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias aliquid amet animi asperiores beatae
            consequuntur error expedita illum in, magni maiores necessitatibus nobis pariatur quae quasi quibusdam sequi
            soluta temporibus.
        </div>
    );
}